package net.mcreator.project.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.project.ProjectMod;

public class RedlightgreenlightProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		{
			Entity _ent = entity;
			_ent.teleportTo(1033, 4, (-258));
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(1033, 4, (-258), _ent.getYRot(), _ent.getXRot());
		}
		if (entity instanceof LivingEntity _entity)
			_entity.setHealth(10);
		if (entity instanceof Player _player && !_player.level.isClientSide())
			_player.displayClientMessage(
					Component.literal("Welcome to Red Light Green Light, walk only when light is green and reach the goal within 3 minutes"),
					(false));
		ProjectMod.queueServerWork(3600, () -> {
			{
				Entity _ent = entity;
				_ent.teleportTo(829, 18, (-446));
				if (_ent instanceof ServerPlayer _serverPlayer)
					_serverPlayer.connection.teleport(829, 18, (-446), _ent.getYRot(), _ent.getXRot());
			}
			if (entity instanceof LivingEntity _entity)
				_entity.setHealth(100);
			if (entity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(Component.literal(
						"Welcome to King Of The Hill , Stay on the top platform to earn points,the least points player loses after 3 minutes"),
						(false));
			ProjectMod.queueServerWork(3600, () -> {
				{
					Entity _ent = entity;
					_ent.teleportTo(1375, 32, (-578));
					if (_ent instanceof ServerPlayer _serverPlayer)
						_serverPlayer.connection.teleport(1375, 32, (-578), _ent.getYRot(), _ent.getXRot());
				}
				if (entity instanceof LivingEntity _entity)
					_entity.setHealth(100);
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(Component.literal("Welcome to Rising Lava, Avoid the lava and survive for 3 minutes"), (false));
				if (world instanceof ServerLevel _level)
					_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO,
							_level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(), "clear");
				ProjectMod.queueServerWork(3600, () -> {
					{
						Entity _ent = entity;
						_ent.teleportTo(1263, 6, (-735));
						if (_ent instanceof ServerPlayer _serverPlayer)
							_serverPlayer.connection.teleport(1263, 6, (-735), _ent.getYRot(), _ent.getXRot());
					}
					if (entity instanceof LivingEntity _entity)
						_entity.setHealth(100);
					if (entity instanceof Player _player && !_player.level.isClientSide())
						_player.displayClientMessage(
								Component.literal(
										"Welcome to Tag, At the end of 3 minutes players with the stick in their inventory will be eliminated."),
								(false));
					if (entity instanceof LivingEntity _entity) {
						ItemStack _setstack = new ItemStack(Items.NAME_TAG);
						_setstack.setCount(1);
						_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
						if (_entity instanceof Player _player)
							_player.getInventory().setChanged();
					}
					ProjectMod.queueServerWork(3600, () -> {
						{
							Entity _ent = entity;
							_ent.teleportTo(1137, 4, (-287));
							if (_ent instanceof ServerPlayer _serverPlayer)
								_serverPlayer.connection.teleport(1137, 4, (-287), _ent.getYRot(), _ent.getXRot());
						}
						if (entity instanceof LivingEntity _entity)
							_entity.setHealth(100);
						if (entity instanceof Player _player && !_player.level.isClientSide())
							_player.displayClientMessage(
									Component.literal("Welcome to Lights Out, Kill other players or Survive for 3 minutes in the darkness"), (false));
					});
				});
			});
		});
	}
}
